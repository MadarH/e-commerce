<?php 
session_start(); 

if (!isset($_SESSION['username'])) {
	header("location: login2.php");
}

{ 

	if(isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);

		header("location: login2.php");

	}  

}
?>

<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Contact us</title>
	<link rel="stylesheet" href="css/style2.css">
	
</head>
<body>

	<?php 

	$server="localhost";
	$username="root";
	$password="";
	$db="sw_db";

	try{
		$conn=new PDO ("mysql:host=$server; dbname=$db",$username,$password);
		$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	}

	catch(PDOException $e){
		echo 'Error: '.$e->getMessage();
	}

	?>
	
	<div class="contact-title">
		<h1>Say Hello</h1>
		<h2>We are always ready to serve you!</h2>
	</div>

	<div class="contact-form">
		<form id="contact-form" method="POST" action="">
			<input name="fName" type="text" class="form-control" placeholder="First Name" required autocomplete="off">

			<br>

			<input name="lName" type="text" class="form-control" placeholder="Last Name" required autocomplete="off">

			<br>

			<input name="eMail" type="text" class="form-control" placeholder="Your Email" required autocomplete="off">

			<br>

			<textarea name="feedback" class="form-control" placeholder="Message" row="6" required autocomplete="off"></textarea>

			<br>


			<input type="submit" name="submit" class="form-control submit" value="Send Message">


			<?php
			if(isset($_POST['submit'])){
				$insert_query = "INSERT INTO 
				feedbackTable ( senderfName,
				senderlName,
				sendereMail,
				senderfeedback)
				VALUES (        '".$_POST["fName"]."',
				'".$_POST["lName"]."',
				'".$_POST["eMail"]."',
				'".$_POST["feedback"]."')";
				$conn->query($insert_query);


				if(empty("fName") || empty("lName") || empty("feedback")){
					header('location:contactus.php?error');
				}

			}



			?>

		</form>



</body>
</html>

