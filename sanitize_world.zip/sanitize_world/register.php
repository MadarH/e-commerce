<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset ="UTF-8">
		<link rel="stylesheet" type="text/css" href="css/styleReg.css">

	<title>Register</title>
</head>

<body>

	<?php include('errors.php'); ?>

	<div class="registerBox">
		
	<img src="css/img/userPic.jpg" class="userPic">
		
		<form name="signup" method="post" action="register.php" onsubmit="return validation()">
			 <h1>Register Here</h1>

			<p>First Name </p>
			<input type="text" name ="firstname" placeholder="Enter First name" autocomplete="off">
			
			<p>Last Name </p>
			<input type="text" name ="lastname" placeholder="Enter Last name" autocomplete="off">

			<p>Email address </p>
			<input type="text" name ="email" placeholder="Enter email address" autocomplete="off">

			<p>Username</p>
			<input type="text" name ="username" placeholder=" Enter Username " autocomplete="off" > 

 			<p>Password</p>
 			<input type="password" name ="password_1" placeholder="Enter Password"  autocomplete="off"> 

		 	<p>Confirm Password</p>
		 	<input type="password" name ="password_2" placeholder="Confirm Password"  autocomplete="off">


			<input type="submit" name= "reg" value="Register"><br>

			<a href="login2.php">Already have an account? Login here</a><br>
			
			<script type="text/javascript">
	function validation()
	{
		var username = document.getElementById("username");
		var password = document.getElementById("password");

		if (username.value.trim() == "")
		{
			//alert("Username blank");
			username.style.border = document.getElementById("t1");
			return false;
		}
		else if (password.value.trim() == "")
		{
			alert("Password blank");
			return false;
		}
		else if(password.value.trim().length<5)
		{ 
			alert("Password too short");
			return false;
		}
		else
		{
			return true;
		}
	}	
	</script>
		</form>
	</div>

</body>
</html>
