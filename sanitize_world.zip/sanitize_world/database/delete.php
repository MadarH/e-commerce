<?php
include 'connect_db.php'; 

//delete.php
if(isset($_POST["id"]))
{
    foreach($_POST["id"] as $id)
    {
        $query = "DELETE FROM products WHERE id = '".$id."'";
        mysqli_query($conn, $query);
    } 
}
?>