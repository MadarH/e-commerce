

<?php  if (count($errors) > 0) : ?>

	<div class="error">


		<?php foreach ($errors as $error) : ?>
		<tr>	<td><h4><?php echo $error ?></h4></td></tr>
		<?php endforeach ?>
	</div>
	<?php  endif ?>
	
