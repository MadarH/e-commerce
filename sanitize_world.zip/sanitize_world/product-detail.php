<?php
	SESSION_START();

	if(!(isset($_SESSION['cart']))) {
		$_SESSION['cart'] = array();
	}

	require_once 'includes/init.php';

	$tmp4 = 0; //using a temp variable, when variable is 1, get function has been called to add to cart

	if(isset($_GET['id'])) {
		$tmp4 = 0;
		$id = mysqli_real_escape_string($db, $_GET['id']);

		$sql = "SELECT * FROM products WHERE id='$id' ";
		$result = mysqli_query($db, $sql) or die("Bad Query : $sql");
		$row = mysqli_fetch_array($result);
		$CAT = $row['cat'];

		$sq = "SELECT * FROM products WHERE cat='$CAT'";
		$related = $db->query($sq);
	}
	else {
		if(isset($_GET['pID'])) {
			$id = mysqli_real_escape_string($db, $_GET['pID']);

			$sql = "SELECT * FROM products WHERE id='$id' ";
			$result = mysqli_query($db, $sql) or die("Bad Query : $sql");
			$row = mysqli_fetch_array($result);
			$CAT = $row['cat'];

			$sq = "SELECT * FROM products WHERE cat='$CAT'";
			$related = $db->query($sq);
		}
	}

	//if clear cart
	if(isset($_GET['clear'])) {
		$_SESSION['cart'] = array();
	}

	$loged = 0;
	if(isset($_SESSION['username'])) {
		$loged = 1;
	}

	//if item exists 
	if(isset($_GET['pID'])) {
		$tmp4 = 1;
		$pID = $_GET['pID'];
		$quan = $_GET['quan'];

		//if quantity chosen is valid and if item is avaible enough
		if($quan > 0 && filter_var($quan, FILTER_VALIDATE_INT) && $quan<$row['qnt']) {
			if(isset($_SESSION['cart'] [$pID])) {
				$_SESSION['cart'] [$pID] += $quan;
			} else {
				$_SESSION['cart'] [$pID] = $quan;
			}
		} else {
			echo "Something went wrong!";
		}
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Product Detail - Sanitize World</title>
	<link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	<div class="container">
		<div class="navbar" style="line-height: 10px;">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" width="125px"></a>
			</div>
			<nav>
				<ul id="MenuItems">
					<?php
						if(isset($_SESSION['username'])) {
							if($_SESSION['username'] == "iven022") {
								echo'<li><a href="index.php">Dashboard</a></li>';
							}
						}
					?>					
					<li><a href="index.php">Home</a></li>
					<li><a href="product.php">Products</a></li>
					<li><a href="">About</a></li>
					<li><a href="">Contact</a></li>
					<?php 
						if ($loged == 0) {
							echo '<li><a href="login2.php">Log In</a></li>';
						} else {
							echo '<li><a href="logout.php">Log Out</a></li>';
						}
					?>
				</ul>
			</nav>
			<a href="cart.php"><img src="images/cart.png" width="30px" height="30px"></a>
			<img src="images/menu.png" class="menu-icon" onclick="menutoggle()">
		</div>
	</div>

	<?php
			if ($tmp4 == 1) {
				echo '
						<div class="added" style="margin-top: -40px;">
							<div class="small-container">
								<div class="row">
									<p>Product succeslly added <i class="fa fa-check" style="color: rgb(0,128,0)"></i></p>
								</div>
								<div class="row">
									<div class="col-2">
										<p class="c1"><a href="cart.php" class="btn">Proceed to checkout &#8594;</a></p>
									</div>
									<div class="col-2">
										<p class="c2"><a href="product.php" class="btn">Go to products page &#8594;</a></p>
									</div>
								</div>	
							</div>
						</div>
				';
			}
	?>

	<div class="small-container single-product" id="p_details">
		<div class="row">
			<div class="col-2">
				<img src="<?= $row['img']; ?>" width="100%" id="ProductImg">
				<div class="small-img-row">
					<?php
						$image = rtrim($row['img'],".jpg");
					?>
					<div class="small-img-col">
						<img src="<?= $image . '-1.jpg';?>" width="100%" class="small-img">
					</div>
					<div class="small-img-col">
						<img src="<?= $image . '-2.jpg';?>" width="100%" class="small-img">
					</div>
					<div class="small-img-col">
						<img src="<?= $image . '-3.jpg';?>" width="100%" class="small-img">
					</div>
					<div class="small-img-col">
						<img src="<?= $image . '-4.jpg';?>" width="100%" class="small-img">
					</div>
				</div>
			</div>
			<div class="col-2">
				<p>Home / <?= $row['cat']; ?></p>
				<h1><?= $row['name']; ?></h1>
				<h4>Rs <?= $row['price']; ?></h4>
				<form action="<?php echo $_SERVER['PHP_SELF']; ?>">
					<input type="number" value="1" name="quan" id="quan">
					<input type="hidden" name="pID" id="pID" value="<?= $row['id']; ?>">
					<input type="submit" onclick="added();" width="100%" class="btn1" value="Add to cart">
				</form>
				<h3>Product Details <i class="fa fa-indent"></i></h3>
				<br>
				<p><?= $row['des']; ?></p>
			</div>
		</div>
	</div>

	<div class="small-container">
		<div class="row row-2">
			<h2>Related Products</h2>
			<p>View More</p>
		</div>
	</div>

	<div class="small-container">
		<div class="row">
			<?php while($product1 = mysqli_fetch_assoc($related)) : ?>
				<div class="col-4">
					<a href='product-detail.php?id=<?= $product1['id'];?>'><img src="<?= $product1['img']; ?>"></a>
					<?php 
						$rating = $product1['rating'];
						if ($rating == 3) {
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star-0";
							$tmp2 = "fa fa-star-0";
						}
						elseif($rating == 4 ){
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp1 = "fa fa-star-0";
						}
						else{
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp2 = "fa fa-star";
						}
					?>
					<h4><?= $product1['name'];?></h4>
					<div class="rating">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="<?= $tmp;?>"></i>
						<i class="<?= $tmp1;?>"></i>
						<i class="<?= $tmp2;?>"></i>
					</div>
					<p>Rs <?= $product1['price']; ?></p>
				</div>
			<?php endwhile; ?>
		</div>
	</div>

	<div class="footer">
			<div class="container">
				<div class="row">
					<div class="footer-col-1">
						<h3>Download Our App</h3>
						<p>Download App for Android and ios mobile phone.</p>
						<div class="app-logo">
							<img src="images/play-store.png">
							<img src="images/app-store.png">
						</div>
					</div>

					<div class="footer-col-2">
						<img src="images/logo-footer.png">
						<p>Our purpose is to sustainably make the world safer by proposing covid safety products safely.</p>
					</div>

					<div class="footer-col-3">
						<h3>Useful Links</h3>
						<ul>
							<li>Coupons</li>
							<li>Blog Post</li>
							<li>Return Policy</li>
							<li>Join Affiliate</li>
						</ul>
					</div>

					<div class="footer-col-4">
						<h3>Follow us</h3>
						<ul>
							<li>Facebook</li>
							<li>Twitter</li>
							<li>Instagram</li>
							<li>Youtube</li>
						</ul>
					</div>
				</div>
			</div>
		<hr><p class="copyright">Copyright 2021</p></hr>
	</div>
		<script>
		 var MenuItems = document.getElementById("MenuItems");
		 MenuItems.style.maxHeight = "0px";
		 function menutoggle(){
		 	if(MenuItems.style.maxHeight == "0px")
		 	{
		 		MenuItems.style.maxHeight = "200px";
		 	}
		 	else{
		 		MenuItems.style.maxHeight = "0px";
		 	}

		 	var ProductImg = document.getElementById("ProductImg");
		 	var SmallImg = document.getElementsByClassName("small-img");
		 	SmallImg[0].onclick = function()
		 	{
		 		ProductImg.src = SmallImg[0].src;
		 	}
		 	SmallImg[1].onclick = function()
		 	{
		 		ProductImg.src = SmallImg[1].src;
		 	}
		 	SmallImg[2].onclick = function()
		 	{
		 		ProductImg.src = SmallImg[2].src;
		 	}
		 	SmallImg[3].onclick = function()
		 	{
		 		ProductImg.src = SmallImg[3].src;
		 	}
		</script>	
</body>
</html>
