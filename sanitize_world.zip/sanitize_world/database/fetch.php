<?php  
    //fetch.php  
    include 'connect_db.php'; 
    if(isset($_POST["products_id"]))  
    {  
    $query  = "SELECT * FROM products WHERE id = '".$_POST["products_id"]."'";  
    $result = mysqli_query($conn, $query);  
    $row    = mysqli_fetch_array($result);  
            echo json_encode($row);  
    }  
 ?>