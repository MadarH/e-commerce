<?php
	SESSION_START();

	if(!(isset($_SESSION['cart']))) {
		$_SESSION['cart'] = array();
	}
	require_once 'includes/init.php';

	if(!(isset($_SESSION['cart']))) {
		$_SESSION['cart'];
	}

	if(isset($_GET['clear'])) {
		$_SESSION['cart'] = array();
	}

	$loged = 0;
	if(isset($_SESSION['username'])) {
		$loged = 1;
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>My Basket - Sanitize World</title>
	<link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	<div class="container">
		<div class="navbar" style="line-height: 10px;">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" width="125px"></a>
			</div>
			<nav>
				<ul id="MenuItems">
					<?php
						if(isset($_SESSION['username'])) {
							if($_SESSION['username'] == "iven022") {
								echo'<li><a href="dashboard.html">Dashboard</a></li>';
							}
						}
					?>	
					<li><a href="index.php">Home</a></li>
					<li><a href="product.php">Products</a></li>
					<li><a href="">About</a></li>
					<li><a href="">Contact</a></li>
					<?php 
						if ($loged == 0) {
							echo '<li><a href="login2.php">Log In</a></li>';
						} else {
							echo '<li><a href="logout.php">Log Out</a></li>';
						}
					?>
				</ul>
			</nav>
			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon" onclick="menutoggle()">
		</div>
	</div>

	<div class="small-container cart-page">
		<table>
			<tr>
				<th>Product</th>
				<th>Quantity</th>
				<th>Subtotal</th>
			</tr>

			<?php
				$grand = 0;
					foreach ($_SESSION['cart'] as $key => $val) {
						$sql = "SELECT * FROM products WHERE id=$key ";
						$result = mysqli_query($db,$sql) or die($sql);
						$row = mysqli_fetch_assoc($result);

						$sub = $val*$row['price'];
						$grand += $sub;
			?>

			<tr>
				<td>
					<div class="cart-info">
						<img src="<?=$row['img'];?>">
						<div>
							<p><?=$row['name'];?></p>
							<small>Categorie: <?=$row['cat'];?></small>
							<br>
							<a href="">Remove</a>
						</div>
					</div>
				</td>
				<td><input type="number" value="<?=$val?>" name=""></td>
				<td><?=$sub?></td>
			</tr>
			<?php
				}
			?>

		</table>
		<br>
		<div class="total-price">
			<table>
				<tr>
					<td>Subtotal</td>
					<td><?=$grand?></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row" style="padding-bottom: 50px; margin-right: -650px;">
		<div class="col-2">
			<?php
				if(isset($_SESSION['username'])) {
					echo '<p class="c1"><a href="checkout.php" class="btn">Proceed to checkout &#8594;</a>';
				}
				else {
					echo '<p class="c1"><a href="login2.php?not_log=1" class="btn">Proceed to checkout &#8594;</a>';
				}
			?>
			<a href="<?= $_SERVER['PHP_SELF'];?>?clear=1" class="btn">Clear Items &#8594;</a></p>
		</div>
	</div>

	<div class="footer">
			<div class="container">
				<div class="row">
					<div class="footer-col-1">
						<h3>Download Our App</h3>
						<p>Download App for Android and ios mobile phone.</p>
						<div class="app-logo">
							<img src="images/play-store.png">
							<img src="images/app-store.png">
						</div>
					</div>

					<div class="footer-col-2">
						<img src="images/logo-footer.png">
						<p>Our purpose is to sustainably make the world safer by proposing covid safety products safely.</p>
					</div>

					<div class="footer-col-3">
						<h3>Useful Links</h3>
						<ul>
							<li>Coupons</li>
							<li>Blog Post</li>
							<li>Return Policy</li>
							<li>Join Affiliate</li>
						</ul>
					</div>

					<div class="footer-col-4">
						<h3>Follow us</h3>
						<ul>
							<li>Facebook</li>
							<li>Twitter</li>
							<li>Instagram</li>
							<li>Youtube</li>
						</ul>
					</div>
				</div>
			</div>
		<hr><p class="copyright">Copyright 2021</p></hr>
	</div>
		<script>
		 var MenuItems = document.getElementById("MenuItems");
		 MenuItems.style.maxHeight = "0px";
		 function menutoggle(){
		 	if(MenuItems.style.maxHeight == "0px")
		 	{
		 		MenuItems.style.maxHeight = "200px";
		 	}
		 	else{
		 		MenuItems.style.maxHeight = "0px";
		 	}
		 }	
		</script>	
</body>
</html>
