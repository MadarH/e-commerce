<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/1.10.11/css/jquery.dataTables.css">
    <link rel="stylesheet" href="css/sweetalert.css">
    <link rel="stylesheet" href="css/style.css">
    <script   src="https://code.jquery.com/jquery-2.2.3.min.js"   integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo="   crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.0.1/Chart.bundle.min.js"></script>
    <script type="text/javascript" charset="utf8" src="http://cdn.datatables.net/1.10.11/js/jquery.dataTables.js"></script>
    <script src="js/sweetalert.min.js"></script> 
    <script src="js/bootstrap.js"></script>
    <script src="js/script.js" type="text/javascript"></script>
</head>
<body>
    
<div id="container">
           <div id="sidebar">
            <img src="images/sidebar.jpg" alt="">
            <div id="overlay">
                <h1>Sanitize World</h1>
                <ul>
                    <li><a href="dashboard.php" class="active"><i class="fa fa-pie-chart" aria-hidden="true"></i> Analytics</a></li>
                    <li><a href="orders.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Orders</a></li>
                    <li><a href="products.php"><i class="fa fa-tag" aria-hidden="true"></i>Products</a></li>
                    <li><a href="users.php"><i class="fa fa-tag" aria-hidden="true"></i>User</a></li>
                    <li><a href="index.php"><i class="fa fa-tag" aria-hidden="true"></i>Home page</a></li>
                </ul>
            </div>
        </div>
    
    <div id="content">
        <div id="topbar">
        <div id="left">
        	<h2>Dashboard / Admin panel</h2>
        </div>
        <div id="right">
        	<p>Hello Admin</p>
        </div> 
   </div>     
    
         
    <div id="cards">
        <div id="card1" class="card">
            <h3>Today’s sales revenue</h3>
            <div id="circle1" class="circle">
                <span><i class="fa fa-usd" aria-hidden="true"></i></span>1.023
            </div>
        </div>
        
        <div id="card2" class="card">    
            <h3>Items sold today</h3>
            <div id="circle1" class="circle">
                <span><i class="fa fa-tags" aria-hidden="true"></i></span>5
            </div>
        </div>
        
        <div id="card3" class="card">    
            <h3>Transactions today</h3>
            <div id="circle1" class="circle">
                <span><i class="fa fa-credit-card-alt" aria-hidden="true"></i></span>1.023
            </div>
            
        </div>
             <canvas id="myChart" width="400" height="110"></canvas>   
    </div>
    </div>
</div>
</body>
</html>