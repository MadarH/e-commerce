<!DOCTYPE html>
<html>
<head>
<title>Feedback Data</title>
	<link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>

		<div class="navbar">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" width="125px"></a>
			</div>
			<nav>
				<ul id="MenuItems">
					<li><a href="index.php">Home</a></li>
						
					<li><a href="product.php">Products</a></li>
					<li><a href="">About</a></li>
					<li><a href="contactus.php">Contact</a></li>
					
				</ul>
			</nav>
			<a href="cart.php">
				<img src="images/cart.png" width="30px" height="30px">
			</a>
			<img src="images/menu.png" class="menu-icon" onclick="menutoggle()">
		</div>



<table>
<tr>
<th>First Name</th>
<th>Email</th>
<th>Message</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "sw_db");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT senderfName, sendereMail, senderfeedback FROM feedbacktable";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["senderfName"]. "</td><td>" . $row["sendereMail"] . "</td><td>"
. $row["senderfeedback"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>
</body>
</html>