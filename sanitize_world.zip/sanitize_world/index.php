<?php
	SESSION_START();
	

	//initialisation of cart if not exists
	if(!(isset($_SESSION['cart']))) {
		$_SESSION['cart'] = array();
	}

	$loged = 0;//variable if 0 = user not loged in
	//checking if user is log in
	if(isset($_SESSION['username'])) {
		$loged = 1;
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sanitize World</title>
	<link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<?php
	require_once 'includes/init.php';

	$sql = "SELECT * FROM products WHERE featured = 1";
	$featured = $db->query($sql);

	$sql1 = "SELECT * FROM products WHERE featured = 0";
	$latest = $db->query($sql1);
?>

<body>
	<div class="header">
	<div class="container">
		<div class="navbar">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" width="125px"></a>
			</div>
			<nav>
				<ul id="MenuItems">
					<?php
						if(isset($_SESSION['username'])) {
							if($_SESSION['username'] == "iven022") {
								echo'<li><a href="dashboard.html">Dashboard</a></li>';
							}
						}
					?>	
					<li><a href="index.php">Home</a></li>
					<li><a href="product.php">Products</a></li>
					<li><a href="">About</a></li>
					<li><a href="">Contact</a></li>
					<?php 
						if ($loged == 0) {
							echo '<li><a href="login2.php">Log In</a></li>';
						} else {
							echo '<li><a href="logout.php">Log Out</a></li>';
						}
					?>
				</ul>
			</nav>
			<a href="cart.php">
				<img src="images/cart.png" width="30px" height="30px">
			</a>
			<img src="images/menu.png" class="menu-icon" onclick="menutoggle()">
		</div>

		<div class="row">
			<div class="col-2" >
				<h1>Your wellbeing is our<br>#1 priority</h1>
				<p>It is not the strongest of species that survives, nor the most intelligent.It is the one that is the most adaptable to change.</p>
				<a href="product.php" class="btn">Explore Now &#8594;</a>
			</div>

			<div class="col-2">
				<img src="images/image1.png">
			</div>
		</div>
	</div>
	</div>

	<div class="categories">
		<div class="small-container">
		<div class="row">
			<div class="col-3">
				<img src="images/category-1.jpg">
			</div>
			<div class="col-3">
				<img src="images/category-2.jpg">
			</div>
			<div class="col-3">
				<img src="images/category-3.jpg">
			</div>
		</div>
		</div>
	</div>

	<div class="small-container">
		<h2 class="title">Featured Products</h2>
			<div class="row">
				<?php while($product = mysqli_fetch_assoc($featured)) : ?>
				<div class="col-4">
					<a href='product-detail.php?id=<?= $product['id'];?>'><img src="<?= $product['img']; ?>"></a>
					<?php 
						$rating = $product['rating'];
						if ($rating == 3) {
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star-0";
							$tmp2 = "fa fa-star-0";
						}
						elseif($rating == 4 ){
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp1 = "fa fa-star-0";
						}
						else{
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp2 = "fa fa-star";
						}
					?>
					<h4><?= $product['name'];?></h4>
					<div class="rating">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="<?= $tmp;?>"></i>
						<i class="<?= $tmp1;?>"></i>
						<i class="<?= $tmp2;?>"></i>
					</div>
					<p>Rs <?= $product['price']; ?></p>
				</div>
				<?php endwhile; ?>
			</div>

		<h2 class="title">Latest Products</h2>
		<div class="row">
			<?php while($product1 = mysqli_fetch_assoc($latest)) : ?>
				<div class="col-4">
					<a href='product-detail.php?id=<?= $product1['id'];?>'><img src="<?= $product1['img']; ?>"></a>
					<?php 
						$rating = $product1['rating'];
						if ($rating == 3) {
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star-0";
							$tmp2 = "fa fa-star-0";
						}
						elseif($rating == 4 ){
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp1 = "fa fa-star-0";
						}
						else{
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp2 = "fa fa-star";
						}
					?>
					<h4><?= $product1['name'];?></h4>
					<div class="rating">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="<?= $tmp;?>"></i>
						<i class="<?= $tmp1;?>"></i>
						<i class="<?= $tmp2;?>"></i>
					</div>
					<p>Rs <?= $product1['price']; ?></p>
				</div>
			<?php endwhile; ?>
		</div>
	</div>

	<div class="offer">
		<div class="small-container">
			<div class="row">
				<div class="col-2">
					<img src="images/exclusive.png" class="offer-img">
				</div>
				<div class="col-2">
					<div class="con">
					<p>Exclusively Available on Santize World</p>
					<h1>COVID-19 Nasal PCR Test</h1>
					<small>FDA AUTHORIZED AT-HOME TEST KIT – The empowerDX COVID-19 Nasal PCR Test has an FDA Emergency Use Authorization (EUA). Our laboratories are CLIA certified and CAP accredited. This test is not for severe symptoms. You must be 18yrs+ to use this test.</small>
					<p><a href="" class="btn">Buy Now &#8594;</a></p>
					</div>
				</div>
			</div>	
		</div>
	</div>

	<div class="testimonial">
		<div class="small-container">
			<div class="row">
				<div class="col-3">
					<i class="fa fa-quote-left"></i>
					<p>The prices proposed are very acceptable but the lack of medecines on the site makes it not perfect. But overall im very satisfy by the website.</p>
					<div class="rating">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star-o"></i>
					</div>
					<img src="images/user-1.png">
					<h3>Emilia Smith></h3>
				</div>

				<div class="col-3">
					<i class="fa fa-quote-left"></i>
					<p>During this hard time, it is so welcoming to have such a facility when buying safety products.</p>
					<div class="rating">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star-half-o"></i>
					</div>
					<img src="images/user-2.png">
					<h3>Sean Parker></h3>
				</div>

				<div class="col-3">
					<i class="fa fa-quote-left"></i>
					<p>Very fast delivery. I was very pleased with the service and the different prices proposed. I'm looking forward to future shopping.</p>
					<div class="rating">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
					</div>
					<img src="images/user-3.png">
					<h3>Valentina Rossi></h3>
				</div>
			</div>
		</div>

		<div class="brands">
			<div class="small-container">
				<div class="row">
					<div class="col-5">
						<img src="images/logo1.png">
					</div>
					<div class="col-5">
						<img src="images/logo2.png">
					</div>
					<div class="col-5">
						<img src="images/logo3.png">
					</div>
					<div class="col-5">
						<img src="images/logo4.png">
					</div>
					<div class="col-5">
						<img src="images/logo5.png">
					</div>
				</div>
			</div>
		</div>

		<div class="footer">
			<div class="container">
				<div class="row">
					<div class="footer-col-1">
						<h3>Download Our App</h3>
						<p>Download App for Android and ios mobile phone.</p>
						<div class="app-logo">
							<img src="images/play-store.png">
							<img src="images/app-store.png">
						</div>
					</div>

					<div class="footer-col-2">
						<a href="index.php"><img src="images/logo-footer.png"></a>
						<p>Our purpose is to sustainably make the world safer by proposing covid safety products safely.</p>
					</div>

					<div class="footer-col-3">
						<h3>Useful Links</h3>
						<ul>
							<li>Coupons</li>
							<li>Blog Post</li>
							<li>Return Policy</li>
							<li>Join Affiliate</li>
						</ul>
					</div>

					<div class="footer-col-4">
						<h3>Follow us</h3>
						<ul>
							<li>Facebook</li>
							<li>Twitter</li>
							<li>Instagram</li>
							<li>Youtube</li>
						</ul>
					</div>
				</div>
			</div>
			<hr><p class="copyright">Copyright 2021</p></hr>
		</div>

		<script>
		 var MenuItems = document.getElementById("MenuItems");
		 MenuItems.style.maxHeight = "0px";
		 function menutoggle(){
		 	if(MenuItems.style.maxHeight == "0px")
		 	{
		 		MenuItems.style.maxHeight = "200px";
		 	}
		 	else{
		 		MenuItems.style.maxHeight = "0px";
		 	}
		 }	
		</script>
</body>
</html>
