<?php  
include 'connect_db.php';
 if(!empty($_POST))  
 {  
     $output       = '';  
     $message      = '';  
     $name      = mysqli_real_escape_string($conn, $_POST["name"]);  
     $des        = mysqli_real_escape_string($conn, $_POST["des"]);  
     $price    = mysqli_real_escape_string($conn, $_POST["price"]);  
     $cat     = mysqli_real_escape_string($conn, $_POST["cat"]);  
     $img   = mysqli_real_escape_string($conn, $_POST["img"]);
     $qnt       = mysqli_real_escape_string($conn, $_POST["qnt"]);
     $featured      = mysqli_real_escape_string($conn, $_POST["featured"]);
     if($_POST["products_id"] != '')  
     {  
          $query = "  
          UPDATE products   
          SET name       = '$name',   
          des             = '$des',   
          price         = '$price',   
          cat          = '$cat',   
          img        = '$img', 
          qnt            = '$qnt',
          featured           = '$featured' 
          WHERE id='".$_POST["products_id"]."'";  
          $message       = 'Data Update has been Successfully!';  
     }  
     else  
     {  
          $query = "  
          INSERT INTO products(name, des, price, cat, img, qnt,featured)  
          VALUES('$name', '$des', '$price', '$cat', '$img', '$qnt', '$featured');  
          ";  
          $message = 'Data insert has been Successfully!';  
     }  
     if(mysqli_query($conn, $query))  
     {  
          $output .= '<label class="text-success">' . $message . '</label>';  
          $select_query = "SELECT * FROM products ORDER BY id DESC";  
          $result = mysqli_query($conn, $select_query);  
          $output .= '  
               <table class="table table-striped table-hover">  
                    <tr>  
                        <th>name</th>  
                        <th>des</th>  
                        <th>price</th>  
                        <th>cat</th>  
                        <th>img</th>
                        <th>qnt</th>  
                        <th>featured</th>  
                        <th>Edit</th>  
                        <th>Delete</th>  
                    </tr>  
          ';  
           while($row = mysqli_fetch_array($result))  
           {  
               $output .= '  
                    <tr>  
                         <td>' . $row["name"] . '</td>  
                         <td>' . $row["des"] . '</td>  
                         <td>' . $row["price"] . '</td>  
                         <td>' . $row["cat"] . '</td>  
                         <td>' . $row["img"] . '</td>  
                         <td>' . $row["qnt"] . '</td>  
                         <td>' . $row["featured"] . '</td>  
                         <td><input type="button" name="edit" value="Edit" qnt="'.$row["qnt"] .'" class="btn btn-info btn-xs edit_data" /></td>  
                         <td><a href="#deleteData" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a></td>  
                    </tr>  
                ';  
          }  
          $output .= '</table>';  
      }  
      echo $output;  
}  
?>
 