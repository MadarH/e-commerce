<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
<meta charset ="UTF-8">
<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/styleLog.css">
	<script>
	function validate()
	{
		var username = document.getElementById("username");
		var password = document.getElementById("password");

		if (username.value.trim() == "")
		{
			//alert("Username blank");
			username.style.border = document.getElementById("t1");
			return false;
		}
		else if (password.value.trim() == "")
		{
			alert("Password blank");
			return false;
		}
		else if(password.value.trim().length<5)
		{ 
			alert("Password too short");
			return false;
		}
		else
		{
			return true;
		}
	}
	</script>
</head>

<body>
	<div class="loginBox">
		<?php include('errors.php'); ?>
	<img src="css/img/userPic.jpg" class="userPic">
		<h1>Login Here</h1>
		<form onsubmit="return validate()" action="login2.php" method="post"> 
			<p>Username </p>
			<input type="text" name="username" placeholder="Enter Username" autocomplete="off" required>
			<p>Password</p>
			<input type="password" name="password" placeholder="Enter Password" required>
			<input type="submit" name="log" value="Login" ><br>
			<a href="#">Forgot Password?</a><br>
			<a href="register.php">Don't have an account? Register here</a><br>
		</form>
	</div>

</body>
</html>