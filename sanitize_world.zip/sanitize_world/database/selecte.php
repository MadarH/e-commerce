  <?php  
 if(isset($_POST["products_id"]))  
 {  
     $output = '';  
     include 'connect_db.php';   
     $query = "SELECT * FROM products WHERE id = '".$_POST["products_id"]."'";  
     $result = mysqli_query($conn, $query);  
     $output .= '  
     <div class="table-responsive">  
           <table class="table table-striped table-hover">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td><label>name</label></td>  
                     <td>'.$row["name"].'</td>  
                </tr>  
                <tr>  
                     <td><label>des</label></td>  
                     <td>'.$row["des"].'</td>  
                </tr>  
                <tr>  
                     <td><label>price</label></td>  
                     <td>'.$row["price"].'</td>  
                </tr>  
                <tr>  
                     <td><label>cat</label></td>  
                     <td>'.$row["cat"].'</td>  
                </tr>  
                <tr>  
                     <td><label>img</label></td>  
                     <td>'.$row["img"].' </td>  
                </tr>  
                <tr>  
                     <td><label>qnt</label></td>  
                     <td>'.$row["qnt"].' </td>  
                </tr>
                <tr>  
                     <td><label>featured</label></td>  
                     <td>'.$row["featured"].' </td>  
                </tr>
           ';  
      }  
      $output .= '  
           </table>  
      </div>  
      ';  
      echo $output;  
 }  
 ?>
 