<?php
  SESSION_START();

  require_once 'includes/init.php';

  if(isset($_SESSION['username'])) {
  } else {
    header('location:index.php');
  }

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['firstname'];
  $email = $_POST['email'];
  $add = $_POST['address'];
  }

  $grand = 0;
  foreach ($_SESSION['cart'] as $key => $val) {
    $sql = "SELECT * FROM products WHERE id=$key ";
    $result = mysqli_query($db,$sql) or die($sql);
    $row = mysqli_fetch_assoc($result);
    $count = mysqli_num_rows($result);
    $q = $row['qnt'];
    $q = $q - $val;

    $sql = "UPDATE products SET qnt=$q WHERE id=$key";
    if ($db->query($sql) != TRUE) {
  		echo "Error updating record: " . $db->error;
	}

    $sub = $val*$row['price'];
    $grand += $sub;
    $sql2 = "INSERT INTO  orders(f_name,email,order_price,ID_user,id_product,quantity)
		VALUES ('$name','$email', '$sub','1' ,'$key','$val')";
    if ($db->query($sql2) != TRUE) {
  		echo "Error: " . $sql2 . "<br>" . $db->error;
	 }
	}
?>