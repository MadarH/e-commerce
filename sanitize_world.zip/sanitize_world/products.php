<?php
    SESSION_START();
    require_once 'database/connect_db.php';
                        
    $sql = "SELECT * FROM products";
    $featured = $conn->query($sql);
                       
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">

    <!-- Font Awesome-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">

    <!-- Sweet Alert CSS -->
    <link rel="stylesheet" href="css/sweetalert.css">

    <!-- My Stylesheet -->
    <link rel="stylesheet" href="css/style.css">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-2.2.3.min.js" integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo=" crossorigin="anonymous"></script>

    <!-- Script Datatable -->
    <script type="text/javascript" charset="utf8" src="http://cdn.datatables.net/1.10.11/js/jquery.dataTables.js"></script>

    <!-- Sweet Alert Script -->
    <script src="js/sweetalert.min.js"></script>

    <!-- Bootstrap Script -->
    <script src="js/bootstrap.js"></script>

    <!-- My Script -->
    <script src="js/script.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/jquery-3.6.0.js"></script>

</head>

<body>


    <div id="container">


      <!-- SIDEBAR MENU -->
       
        <div id="sidebar">
            <img src="images/sidebar.jpg" alt="">
            <div id="overlay">
                <h1>Sanitize World</h1>

                <ul>
                    <li><a href="dashboard.php"><i class="fa fa-pie-chart" aria-hidden="true"></i> Analytics</a></li>
                    <li><a href="orders.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Orders</a></li>
                    <li><a href="products.php"><i class="fa fa-tag" aria-hidden="true"></i>Products</a></li>
                    <li><a href="users.php"><i class="fa fa-tag" aria-hidden="true"></i>User</a></li>
                    <li><a href="index.php"><i class="fa fa-tag" aria-hidden="true"></i>Home page</a></li>
                </ul>

            </div>

        </div>
        
    

        <div id="content">

           <br /><br />  
<div class="container">  
    <h3 align="center"><u>Admin Panel</u></h3>  
    <div class="table-wrapper">
      <div class="table-title">
        <div class="row">
          <div class="col-sm-6">
            <h2>Manage <b>products</b></h2>
          </div>
          <div class="col-sm-6">
            <button type="button" name="add" id="add" data-toggle="modal" data-target="#add_data" class="btn btn-warning">Add New Products</button>
            <a type="button" name="btn_delete" id="btn_delete" class="btn btn-danger" data-toggle="modal" data-target="#deleteData">Delete</a>                    
          </div>
        </div>
      </div>
            
      <br />  
      <div id="data_table">  
        <table class="table table-striped table-hover">  
          <tr> 
            <th>
            </th> 
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Category</th>
            <th>Image</th>  
            <th>Quantity</th>  
            <th>Featured</th> 
            <th>Edit</th>  
          </tr>  
          <?php  
          while($row = mysqli_fetch_array($featured))
          {  
          ?>  
            <tr>  
              <td>
                <span class="custom-checkbox">
                  <input type="checkbox" id="checkbox1" name="checkbox" value="<?php echo $row['id']; ?>">
                  <label for="checkbox1"></label>
                </span>
              </td>
                <td><?php echo $row["id"]; ?></td>
                <td><?php echo $row["name"]; ?></td>
                <td><?php echo $row["des"]; ?></td>
                <td><?php echo $row["price"]; ?></td>
                <td><?php echo $row["cat"]; ?></td>
                <td><?php echo $row["img"]; ?></td>  
                <td><?php echo $row["qnt"]; ?></td>  
                <td><?php echo $row["featured"]; ?></td>  
                <td><input type="button" name="edit" value="Edit" id="<?php echo $row['id']; ?>" class="btn btn-info btn-xs edit_data" />
              </td>  
            </tr>  
          <?php  
          }  
          ?>  
        </table>  
      </div>  
    </div>  
</div>

<footer>
  <p class="p-3 text-center"></p>
</footer> 

</body>  
</html>  
<div id="dataModal" class="modal fade">  
  <div class="modal-dialog">  
    <div class="modal-content">  
      <div class="modal-header">  
        <button type="button" class="close" data-dismiss="modal">&times;</button>  
        <h4 class="modal-title">Products Details</h4>  
      </div>  
      <div class="modal-body" id="products_details">  
      </div>  
      <div class="modal-footer">  
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
      </div>  
    </div>  
  </div>  
</div>  
<!-- Add Data -->
<div id="add_data" class="modal fade">  
  <div class="modal-dialog">  
    <div class="modal-content">  
      <div class="modal-header">  
        <button type="button" class="close" data-dismiss="modal">&times;</button>  
        <h4 class="modal-title">Insert</h4>  
      </div>  
      <div class="modal-body">  
        <form method="post" id="insert_form">  
          <label>Name</label>  
          <input type="text" name="name" id="name" class="form-control" required/>  
          <br />  
          <label>Description</label>  
          <input type="text" name="des" id="des" class="form-control" />  
          <br />
          <label>Price</label>  
          <input type="text" name="price" id="price" class="form-control" />  
          <br />
          <label>category</label>  
          <input type="text" name="cat" id="cat" class="form-control" />  
          <br /> 
          <label>image</label>  
          <textarea name="img" id="img" class="form-control" required></textarea> 
          <br />
          <label>Quantity</label>  
          <textarea name="qnt" id="qnt" class="form-control" required></textarea> 
          <br />
          <label>Featured</label>  
          <textarea name="featured" id="featured" class="form-control" required></textarea> 
          <br />
          <input type="hidden" name="products_id" id="products_id" />  
          <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />  
        </form>  
      </div>  
      <div class="modal-footer">  
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
      </div>  
    </div>  
  </div>  
</div> 

<script>
$(document).ready(function()
{
 
$('#btn_delete').click(function()
{
  
     if(confirm("Are you sure you want to delete this?"))
     {
     var id = [];
     
     $(':checkbox:checked').each(function(i)
     {
          id[i] = $(this).val();
     });
     
          if(id.length === 0) //tell you if the array is empty
          {
               alert("Please Select atleast one checkbox");
          }
          else
          {
          $.ajax({
               url:'database/delete.php',
               method:'POST',
               data:{id:id},
               success:function()
          {
          for(var i=0; i<id.length; i++)
          {
               $('tr#'+id[i]+'').css('background-color', '#ccc');
               $('tr#'+id[i]+'').fadeOut('slow');
               }
          }
          
     });
     }
     
     }
     else
     {
     return false;
     }
     });
});
</script>
 
 <script>  
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      });  
      $(document).on('click', '.edit_data', function(){  
           var products_id = $(this).attr("id");  
           $.ajax({  
               url:"database/fetch.php",  
               method:"POST",  
               data:{products_id:products_id},  
               dataType:"json",  
               success:function(data){  
                    $('#name').val(data.name);  
                    $('#des').val(data.des);  
                    $('#price').val(data.price);  
                    $('#cat').val(data.cat);  
                    $('#img').val(data.img);  
                    $('#qnt').val(data.qnt);  
                    $('#featured').val(data.featured);  
                    $('#products_id').val(data.id);  
                    $('#insert').val("Update");  
                    $('#add_data').modal('show');   
                }  
           });  
      });  
      $('#insert_form').on("submit", function(event){  
            event.preventDefault();  
            if($('#name').val() == "")  
            {  
               alert("name is required");  
            }  
            else if($('#des').val() == '')  
            {  
               alert("description required");  
            }
            else if($('#price').val() == '')  
            {  
               alert("price required");  
            } 
            else if($('#qnt').val() == '')  
            {  
               alert("Quantity required");  
            }  
            else if($('#img').val() == '')  
            {  
               alert("image is required");  
            }  
            else  
            {  
               $.ajax({  
                    url:"database/insert.php",  
                    method:"POST",  
                    data:$('#insert_form').serialize(),  
                    beforeSend:function()
                    {  
                         $('#insert').val("Inserting");  
                    },  
                    success:function(data)
                    {  
                         $('#insert_form')[0].reset();  
                         $('#add_data').modal('hide');  
                         $('#data_table').html(data);  
                    }  
               });  
          }
      });  
      
});  
</script>
<script>
     $(document).ready(function()
     {
          setTimeout(function()
          {
               $('#message').hide();
          },3000);
     });
</script>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
</body>
</html>