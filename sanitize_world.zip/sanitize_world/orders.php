<?php
    SESSION_START();
    require_once 'includes/init.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    
     <!-- Font Awesome-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">

    <!-- Sweet Alert CSS -->
    <link rel="stylesheet" href="css/sweetalert.css">

    <!-- My Stylesheet -->
    <link rel="stylesheet" href="css/style.css">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-2.2.3.min.js" integrity="sha256-a23g1Nt4dtEYOj7bR+vTu7+T8VP13humZFBJNIYoEJo=" crossorigin="anonymous"></script>

    <!-- Script Datatable -->
    <script type="text/javascript" charset="utf8" src="http://cdn.datatables.net/1.10.11/js/jquery.dataTables.js"></script>

    <!-- Sweet Alert Script -->
    <script src="js/sweetalert.min.js"></script>

    <!-- Bootstrap Script -->
    <script src="js/bootstrap.js"></script>

    <!-- My Script -->
    <script src="js/script.js" type="text/javascript"></script>

    
    
</head>
<body>
    



<div class="pop-over">
<div class="triangle"></div>
</div>


<div id="container">
   <!-- SIDEBAR -->
           <div id="sidebar">
            <img src="images/sidebar.jpg" alt="">
            <div id="overlay">
                <h1>Sanitize World</h1>

                <ul>
                    <li><a href="dashboard.php"><i class="fa fa-pie-chart" aria-hidden="true"></i> Analytics</a></li>
                    <li><a href="orders.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Orders</a></li>
                    <li><a href="products.php"><i class="fa fa-tag" aria-hidden="true"></i>Products</a></li>
                    <li><a href="users.php"><i class="fa fa-tag" aria-hidden="true"></i>User</a></li>
                     <li><a href="index.php"><i class="fa fa-tag" aria-hidden="true"></i>Home page</a></li>
                </ul>

            </div>

        </div>
    
    
    <div id="content">
    
 
    

        
        <div id="topbar">
        <div id="left">
        <h2>Dashboard / Admin panel</h2>
        </div>
        <div id="right">
        <p>Hello Admin</p>

        </div>
          <div class="clear"></div> 
        </div>
        <div id=space></div>
        
        
        <div id="cards">
           
           <h3>Orders</h3>
           <input type="text" placeholder="search" id="search">
           
            <!--TABLE-->
           <table class="table table-striped">
             <thead>
              <tr>
               <th>Full Name</th>
               <th>Email</th>
               <th>Shipping-Address</th>
               <th>Price</th>
               <th>User ID</th>
               <th>Product ID</th>
               <th>Quantity/th>
               <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php
              $sql = "SELECT * FROM orders";
              $featured = $db->query($sql);
            ?>
            <?php while($orders = mysqli_fetch_assoc($featured)) : ?>
              <tr>
                  <td><?=$orders['f_name'];?></td>
                  <td><?=$orders['email'];?></td>
                  <td><?=$orders['add'];?></td>
                  <td><?=$orders['order_price'];?></td>
                  <td><?=$orders['ID_user'];?></td>
                  <td><?=$orders['id_product'];?></td>
                  <td><?=$orders['quantity'];?></td>
                  <td>
                      <a href="#"><i class="fa fa-eye actions" aria-hidden="true"></i></a>
                      <a href="#"><i class="fa fa-pencil actions" aria-hidden="true"></i></a>
                  </td>
              </tr>  
              <?php endwhile; ?>            
              </tbody>               
           </table>
        </div>
    </div>
</div>
</body>
</html>