<?php
	SESSION_START();
	require_once 'includes/init.php';
	$temp = 1 ;

	//collect post data from search
	if(isset($_POST['search'])) {
		$temp = 0 ;
		$searchq = $_POST['search'];
		$searchq = preg_replace("#[^0-9a-z]#i", "", $searchq);
		$sql = "SELECT * FROM products WHERE name LIKE '%$searchq%' or cat LIKE '%$searchq%'";
		$items = $db->query($sql);
		$count = mysqli_num_rows($items);
		if($count == 0) {
			echo '<script>alert("No result found!")</script>';
  
		}
	}
	else {
		$sql = "SELECT * FROM products";
		$items = $db->query($sql);
	}

	$loged = 0;
	if(isset($_SESSION['username'])) {
		$loged = 1;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>All Products - Sanitize World</title>
	<link rel="stylesheet" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
</head>

<body>
	<div class="container">
		<div class="navbar" style="line-height: 10px;">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" width="125px"></a>
			</div>
			<nav>
				<ul id="MenuItems">
					<?php
						if(isset($_SESSION['username'])) {
							if($_SESSION['username'] == "iven022") {
								echo'<li><a href="dashboard.html">Dashboard</a></li>';
							}
						}
					?>	
					<li><a href="index.php">Home</a></li>
					<li><a href="product.php">Products</a></li>
					<li><a href="">About</a></li>
					<li><a href="">Contact</a></li>
					<?php 
						if ($loged == 0) {
							echo '<li><a href="login2.php">Log In</a></li>';
						} else {
							echo '<li><a href="logout.php">Log Out</a></li>';
						}
					?>
				</ul>
			</nav>
			<img src="images/cart.png" width="30px" height="30px">
			<img src="images/menu.png" class="menu-icon" onclick="menutoggle()">
		</div>
	</div>


	<div class="box">
		<form method="post">
			<input type="text" name="search" placeholder="Search for a product">
			<input type="submit" value="Search" name="submit">
		</form>
	</div>
	<br>

	<div class="small-container" style="margin-top: -100px;">
		<div class="row row-2">
			<?php 
				if ($temp == 1) {
					echo '<h2>All products</h2>';
				} else {
					echo '<h2>Results</h2>';
				}
			?>
			
			<select onchange="sort_p()" id="sort_p">
					<option>Default Sort</option>
					<option>Sort by price</option>
					<option>Sort by popularity</option>
					<option>Sort by rating</option>
					<option>Sort by sale</option>
			</select>
		</div>



			<div class="row">
				<?php while($product = mysqli_fetch_assoc($items)) : ?>
				<div class="col-4">
					<a href='product-detail.php?id=<?= $product['id'];?>'><img src="<?= $product['img']; ?>"></a>
					<?php 
						$rating = $product['rating'];
						if ($rating == 3) {
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star-0";
							$tmp2 = "fa fa-star-0";
						}
						elseif($rating == 4 ){
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp1 = "fa fa-star-0";
						}
						else{
							$tmp = "fa fa-star";
							$tmp1 = "fa fa-star";
							$tmp2 = "fa fa-star";
						}
					?>
					<h4><?= $product['name'];?></h4>
					<div class="rating">
						<i class="fa fa-star"></i>
						<i class="fa fa-star"></i>
						<i class="<?= $tmp;?>"></i>
						<i class="<?= $tmp1;?>"></i>
						<i class="<?= $tmp2;?>"></i>
					</div>
					<p>Rs <?= $product['price']; ?></p>
				</div>
				<?php endwhile; ?>
			</div>

		<div class="page-btn">
			<span>1</span>
			<span>2</span>
			<span>3</span>
			<span>4</span>
			<span>&#8594;</span>
		</div>
	</div>

	<div class="footer">
			<div class="container">
				<div class="row">
					<div class="footer-col-1">
						<h3>Download Our App</h3>
						<p>Download App for Android and ios mobile phone.</p>
						<div class="app-logo">
							<img src="images/play-store.png">
							<img src="images/app-store.png">
						</div>
					</div>

					<div class="footer-col-2">
						<img src="images/logo-footer.png">
						<p>Our purpose is to sustainably make the world safer by proposing covid safety products safely.</p>
					</div>

					<div class="footer-col-3">
						<h3>Useful Links</h3>
						<ul>
							<li>Coupons</li>
							<li>Blog Post</li>
							<li>Return Policy</li>
							<li>Join Affiliate</li>
						</ul>
					</div>

					<div class="footer-col-4">
						<h3>Follow us</h3>
						<ul>
							<li>Facebook</li>
							<li>Twitter</li>
							<li>Instagram</li>
							<li>Youtube</li>
						</ul>
					</div>
				</div>
			</div>
		<hr><p class="copyright">Copyright 2021</p></hr>
	</div>
		<script>
		 var MenuItems = document.getElementById("MenuItems");
		 MenuItems.style.maxHeight = "0px";
		 function menutoggle(){
		 	if(MenuItems.style.maxHeight == "0px")
		 	{
		 		MenuItems.style.maxHeight = "200px";
		 	}
		 	else{
		 		MenuItems.style.maxHeight = "0px";
		 	}
		 }	
		</script>	
</body>
</html>
