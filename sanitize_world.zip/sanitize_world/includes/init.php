<?php
	$db = mysqli_connect('127.0.0.1','root','','sw_db');
	if(mysqli_connect_error()) {
		echo "Database connection failed with following errors: " . mysqli_connect_error();
		die();
	}

	define('BASEURL', '/sanitize/')
?>